import React from 'react'

export default () =>{

    const informacao = 'Primeiro componente JSX'

    return(
        <>
            <h2>Componente OlaMundo</h2>
            <p>{ informacao }</p>
        </>
    )
}
